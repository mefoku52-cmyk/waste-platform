"""Auto-generated."""
