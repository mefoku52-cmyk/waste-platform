'use client';

import { useDocuments } from '../hooks/use-documents';

export const DocumentsTable = () => {
  const { data, isLoading, error } = useDocuments();
  const items = (data as any)?.items ?? [];

  if (isLoading) {
    return <div className="p-4 text-center text-sm text-gray-500">Načítavam dokumenty...</div>;
  }
  if (error) {
    return <div className="p-4 text-center text-sm text-red-600">Dokumenty sa nepodarilo načítať.</div>;
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
      <table className="min-w-full divide-y divide-gray-200 bg-white text-sm">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-2 text-left font-medium text-gray-900">Názov</th>
            <th className="px-4 py-2 text-left font-medium text-gray-900">Typ</th>
            <th className="px-4 py-2 text-left font-medium text-gray-900">Status</th>
            <th className="px-4 py-2 text-left font-medium text-gray-900">Súbor</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {items.length === 0 ? (
            <tr>
              <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                Žiadne dokumenty.
              </td>
            </tr>
          ) : (
            items.map((doc: any) => (
              <tr key={doc.id} className="hover:bg-gray-50">
                <td className="px-4 py-2 font-medium text-gray-900">{doc.title}</td>
                <td className="px-4 py-2 text-gray-700">{doc.documentType || doc.document_type}</td>
                <td className="px-4 py-2 text-gray-700">{doc.status}</td>
                <td className="px-4 py-2">
                  {(doc.fileUrl || doc.file_url) ? (
                    <a
                      href={doc.fileUrl || doc.file_url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      Otvoriť
                    </a>
                  ) : (
                    '—'
                  )}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};
