"""Auto-generated stub."""
