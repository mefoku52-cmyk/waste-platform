import { http } from '../../lib/api/http';
import { PaginatedResponse } from '../../lib/types/common';
import { Listing } from './types';
import { ListingInput } from './schemas';

export const listingsApi = {
  getListings: (params?: Record<string, any>) =>
    http.get<PaginatedResponse<Listing>>('/listings', { ...params }),

  getMarketplace: (params?: Record<string, any>) =>
    http.get<PaginatedResponse<Listing>>('/listings/marketplace', { ...params }),

  getListing: (id: string) =>
    http.get<Listing>(`/listings/${id}`),

  createListing: (data: ListingInput) =>
    http.post<Listing>('/listings', data),

  updateListing: (id: string, data: Partial<ListingInput> & { status?: string }) =>
    http.put<Listing>(`/listings/${id}`, data),

  publishListing: (id: string) =>
    http.post<{ data: any }>(`/listings/${id}/publish`, {}),

  deleteListing: (id: string) =>
    http.delete(`/listings/${id}`),

  getMatches: (materialType: string, params?: Record<string, any>) =>
    http.get<PaginatedResponse<Listing>>(`/listings/matches?materialType=${encodeURIComponent(materialType)}`, { ...params }),
};
