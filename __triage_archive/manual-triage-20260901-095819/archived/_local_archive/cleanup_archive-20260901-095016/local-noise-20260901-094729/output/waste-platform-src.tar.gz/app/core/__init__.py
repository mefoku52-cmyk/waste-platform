"""CMEP core package."""
