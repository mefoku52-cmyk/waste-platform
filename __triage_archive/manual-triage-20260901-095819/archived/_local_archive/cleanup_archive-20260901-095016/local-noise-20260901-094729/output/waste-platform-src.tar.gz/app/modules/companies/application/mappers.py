from app.modules.companies.application.dto import CompanyDTO
from app.modules.companies.domain.entities import Company


def to_company_dto(company: Company) -> CompanyDTO:
    return CompanyDTO(
        id=company.id,
        status=company.status.value,
        legal_name=company.legal_name,
        trading_name=company.trading_name,
        registration_number=company.registration_number,
        tax_identifier=company.tax_identifier,
        company_type=company.company_type.value,
        email=company.email,
        phone=company.phone,
        website_url=company.website_url,
        country_code=company.country_code,
        address_line_1=company.address_line_1,
        address_line_2=company.address_line_2,
        city=company.city,
        postal_code=company.postal_code,
        latitude=company.latitude,
        longitude=company.longitude,
        seller_capability=company.seller_capability,
        buyer_capability=company.buyer_capability,
        logistics_capability=company.logistics_capability,
        verification_submitted_at=company.verification_submitted_at,
        verification_reviewed_at=company.verification_reviewed_at,
        verification_reviewed_by_user_id=company.verification_reviewed_by_user_id,
        verified_at=company.verified_at,
        verified_by_user_id=company.verified_by_user_id,
        rejected_at=company.rejected_at,
        rejected_by_user_id=company.rejected_by_user_id,
        created_at=company.created_at,
        created_by_user_id=company.created_by_user_id,
        updated_at=company.updated_at,
        updated_by_user_id=company.updated_by_user_id,
    )
